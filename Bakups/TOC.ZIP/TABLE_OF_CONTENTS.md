
# Table of Contents  Advanced Bash Scripting Guide

_Last generated: 2025-07-10_

| # | Chapter File | Title |
|---|--------------|-------|
| 1 | [01_strict_mode.md](01_strict_mode.md) | Strict Mode & Core Terminology |
| 2 | [02_variables_arrays.md](02_variables_arrays.md) | Variables, Arrays & Parameter Expansion |
| 3 | [03_functions_loops.md](03_functions_loops.md) | Functions, Libraries & Loop Patterns |
| 4 | [04_text_processing.md](04_text_processing.md) | Text Processing DeepDive |
| 5 | [05_service_ops.md](05_service_ops.md) | Service Monitoring & Editing |
| 6 | [06_remote_exec.md](06_remote_exec.md) | Remote Execution & File Transfer |
| 7 | [07_csv_workflows.md](07_csv_workflows.md) | CSV / TSV Workflows |
| 8 | [08_crypto_security.md](08_crypto_security.md) | Cryptography & Secrets Management |
| 9 | [09_playbooks.md](09_playbooks.md) | Full Playbooks & Rollouts |
|10 | [10_ci_testing.md](10_ci_testing.md) | Testing, Linting & CI/CD |
|11 | [11_reference_tables.md](11_reference_tables.md) | Reference Tables & CheatSheets |
